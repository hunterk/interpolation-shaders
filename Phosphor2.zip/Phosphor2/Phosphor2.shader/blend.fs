#version 150

uniform sampler2D	source[];
uniform vec4		sourceSize[];
uniform vec4 		targetSize;
uniform vec4 		outputSize;

in Vertex {
	vec2 texCoord;
};
out vec4 fragColor;

#in showPhosphors
#in showImage
#in sharpnessX
#in phosphorCount
#in spacingX
#in spacingY
#in pWidth
#in darkenWhenZoomed


// #in myContrast
void main() {
	
#ifndef showImage
	fragColor=texture2D(source[0], texCoord.xy);
	return;
#endif
#ifndef showPhosphors
	fragColor=texture2D(source[1], texCoord.xy);
	return;
#endif
	vec4 original=texture2D(source[1], texCoord.xy);
	
	// original=pow(original,vec4(2.2));

	// original*=myContrast;
	vec4 phosphor=texture2D(source[0], texCoord.xy);
	// phosphor=pow(phosphor,vec4(2.2));
	vec4 outColor=original*phosphor;
	// outColor=pow(outColor,vec4(1.0/2.2));
	
	float calibration=3.0/((1-0.5*spacingY)*(1-0.5*spacingX)*pWidth);	
#ifdef darkenWhenZoomed
	outColor*=max(calibration*targetSize.x*outputSize.z,1.0);
#else
	outColor*=calibration;
#endif
	
	
	fragColor=outColor;
	// fragColor=vec4(c.r,c.g,c.b,1.0);
}
