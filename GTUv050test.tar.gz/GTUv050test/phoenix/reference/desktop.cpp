namespace phoenix {

Size pDesktop::size() {
  return {0, 0};
}

Geometry pDesktop::workspace() {
  return {0, 0, 0, 0};
}

}
