#include <nall/xorg/guard.hpp>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>
#include <gdk/gdkkeysyms.h>
#include <cairo.h>
#include <X11/Xatom.h>
#include <nall/xorg/guard.hpp>
