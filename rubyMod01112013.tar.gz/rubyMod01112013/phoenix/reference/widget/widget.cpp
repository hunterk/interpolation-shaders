namespace phoenix {

bool pWidget::enabled() {
  return false;
}

bool pWidget::focused() {
  return false;
}

Size pWidget::minimumSize() {
  return {0, 0};
}

void pWidget::setEnabled(bool enabled) {
}

void pWidget::setFocused() {
}

void pWidget::setFont(string font) {
}

void pWidget::setGeometry(Geometry geometry) {
}

void pWidget::setVisible(bool visible) {
}

void pWidget::constructor() {
}

void pWidget::destructor() {
}

}
