namespace phoenix {

unsigned pHorizontalSlider::position() {
  return 0;
}

void pHorizontalSlider::setLength(unsigned length) {
}

void pHorizontalSlider::setPosition(unsigned position) {
}

void pHorizontalSlider::constructor() {
}

void pHorizontalSlider::destructor() {
}

}
