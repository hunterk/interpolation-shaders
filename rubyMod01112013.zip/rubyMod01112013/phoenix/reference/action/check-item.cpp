namespace phoenix {

bool pCheckItem::checked() {
  return false;
}

void pCheckItem::setChecked(bool checked) {
}

void pCheckItem::setText(string text) {
}

void pCheckItem::constructor() {
}

void pCheckItem::destructor() {
}

}
