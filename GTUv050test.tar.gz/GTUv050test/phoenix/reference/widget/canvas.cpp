namespace phoenix {

void pCanvas::setDroppable(bool droppable) {
}

void pCanvas::setSize(Size size) {
}

void pCanvas::update() {
}

void pCanvas::constructor() {
}

void pCanvas::destructor() {
}

}
