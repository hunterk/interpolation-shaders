namespace phoenix {

void pButton::setImage(const image& image, Orientation orientation) {
}

void pButton::setText(string text) {
}

void pButton::constructor() {
}

void pButton::destructor() {
}

}
