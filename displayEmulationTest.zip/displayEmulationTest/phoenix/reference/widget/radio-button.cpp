namespace phoenix {

bool pRadioButton::checked() {
  return false;
}

void pRadioButton::setChecked() {
}

void pRadioButton::setGroup(const group<RadioButton>& group) {
}

void pRadioButton::setText(string text) {
}

void pRadioButton::constructor() {
}

void pRadioButton::destructor() {
}

}
