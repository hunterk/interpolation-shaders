namespace phoenix {

unsigned pVerticalScroller::position() {
  return 0;
}

void pVerticalScroller::setLength(unsigned length) {
}

void pVerticalScroller::setPosition(unsigned position) {
}

void pVerticalScroller::constructor() {
}

void pVerticalScroller::destructor() {
}

}
