namespace phoenix {

void pObject::constructor() {
}

void pObject::destructor() {
}

}
