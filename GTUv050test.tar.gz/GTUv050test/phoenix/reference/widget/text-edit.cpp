namespace phoenix {

void pTextEdit::setCursorPosition(unsigned position) {
}

void pTextEdit::setEditable(bool editable) {
}

void pTextEdit::setText(string text) {
}

void pTextEdit::setWordWrap(bool wordWrap) {
}

string pTextEdit::text() {
}

void pTextEdit::constructor() {
}

void pTextEdit::destructor() {
}

}
