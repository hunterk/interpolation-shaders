namespace phoenix {

void pHexEdit::setColumns(unsigned columns) {
}

void pHexEdit::setLength(unsigned length) {
}

void pHexEdit::setOffset(unsigned offset) {
}

void pHexEdit::setRows(unsigned rows) {
}

void pHexEdit::update() {
}

void pHexEdit::constructor() {
}

void pHexEdit::destructor() {
}

}
