namespace phoenix {

void pComboButton::append(string text) {
}

void pComboButton::modify(unsigned row, string text) {
}

void pComboButton::remove(unsigned row) {
}

void pComboButton::reset() {
}

unsigned pComboButton::selection() {
  return 0;
}

void pComboButton::setSelection(unsigned row) {
}

void pComboButton::constructor() {
}

void pComboButton::destructor() {
}

}
