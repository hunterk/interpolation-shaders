namespace phoenix {

void pApplication::run() {
}

bool pApplication::pendingEvents() {
  return false;
}

void pApplication::processEvents() {
}

void pApplication::quit() {
}

void pApplication::initialize() {
}

}
