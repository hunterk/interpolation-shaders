namespace phoenix {

static Settings* settings = nullptr;

}
