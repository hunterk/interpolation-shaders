namespace phoenix {

void pItem::setImage(const image& image) {
}

void pItem::setText(string text) {
}

void pItem::constructor() {
}

void pItem::destructor() {
}

}
