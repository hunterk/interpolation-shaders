namespace phoenix {

void pTimer::setEnabled(bool enabled) {
}

void pTimer::setInterval(unsigned milliseconds) {
}

void pTimer::constructor() {
}

void pTimer::destructor() {
}

}
