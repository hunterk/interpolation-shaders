namespace phoenix {

unsigned pVerticalSlider::position() {
  return 0;
}

void pVerticalSlider::setLength(unsigned length) {
}

void pVerticalSlider::setPosition(unsigned position) {
}

void pVerticalSlider::constructor() {
}

void pVerticalSlider::destructor() {
}

}
