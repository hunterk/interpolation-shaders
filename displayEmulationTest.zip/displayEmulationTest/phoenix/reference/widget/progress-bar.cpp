namespace phoenix {

void pProgressBar::setPosition(unsigned position) {
}

void pProgressBar::constructor() {
}

void pProgressBar::destructor() {
}

}
