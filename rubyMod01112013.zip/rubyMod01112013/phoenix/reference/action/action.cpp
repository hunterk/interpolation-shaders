namespace phoenix {

void pAction::setEnabled(bool enabled) {
}

void pAction::setVisible(bool visible) {
}

void pAction::constructor() {
}

void pAction::destructor() {
}

}
