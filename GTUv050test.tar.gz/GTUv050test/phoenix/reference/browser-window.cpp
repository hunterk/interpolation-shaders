namespace phoenix {

string pBrowserWindow::directory(BrowserWindow::State& state) {
  return "";
}

string pBrowserWindow::open(BrowserWindow::State& state) {
  return "";
}

string pBrowserWindow::save(BrowserWindow::State& state) {
  return "";
}

}
