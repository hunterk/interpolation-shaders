#include "phoenix.hpp"
using namespace nall;
using namespace phoenix;

int main() {
  OS::main();
  return 0;
}
