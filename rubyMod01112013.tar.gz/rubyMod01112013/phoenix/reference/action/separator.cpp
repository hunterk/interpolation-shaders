namespace phoenix {

void pSeparator::constructor() {
}

void pSeparator::destructor() {
}

}
