namespace phoenix {

bool pRadioItem::checked() {
  return false;
}

void pRadioItem::setChecked() {
}

void pRadioItem::setGroup(const group<RadioItem>& group) {
}

void pRadioItem::setText(string text) {
}

void pRadioItem::constructor() {
}

void pRadioItem::destructor() {
}

}
