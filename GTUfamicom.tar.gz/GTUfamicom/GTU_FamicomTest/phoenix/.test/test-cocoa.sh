./test-cocoa.app/Contents/MacOS/test-cocoa
