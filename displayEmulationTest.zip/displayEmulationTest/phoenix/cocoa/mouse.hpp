namespace phoenix {

struct pMouse {
  static Position position();
  static bool pressed(Mouse::Button button);
};

}
