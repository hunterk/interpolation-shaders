namespace phoenix {

void pLabel::setText(string text) {
}

void pLabel::constructor() {
}

void pLabel::destructor() {
}

}
