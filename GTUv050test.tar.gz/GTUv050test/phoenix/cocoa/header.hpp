#define decimal CocoaDecimal
#import <Cocoa/Cocoa.h>
#import <Carbon/Carbon.h>
#undef decimal
