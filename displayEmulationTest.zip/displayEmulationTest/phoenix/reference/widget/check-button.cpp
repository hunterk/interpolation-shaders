namespace phoenix {

bool pCheckButton::checked() {
  return false;
}

void pCheckButton::setChecked(bool checked) {
}

void pCheckButton::setText(string text) {
}

void pCheckButton::constructor() {
}

void pCheckButton::destructor() {
}

}
