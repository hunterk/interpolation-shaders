namespace phoenix {

void pConsole::print(string text) {
}

void pConsole::reset() {
}

void pConsole::constructor() {
}

void pConsole::destructor() {
}

}
